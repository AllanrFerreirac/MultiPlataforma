<img src="https://user-images.githubusercontent.com/61523977/177602277-0cb2a53d-e415-4462-9244-e241e9f8ac3c.png" width="20%" heigth="20%">
<h2 align"center">Projeto Multiplataforma - WEB / DESKTOP / MOBILE</h1><img src="https://img.shields.io/github/stars/Amaral1973/multiplataforma?style=social"/>
<h4 align="center">🚧 Multiplataforma em construção... 🚧</h4>
<h4>💻 Sobre o projeto</h4>
<hr/>
Projeto multiplataforma, construção de aplicativos web; usando PHP, HTML5 e Bootstrap, desktop; usando C# e WindowsForms e mobile; usando Xamarin.Forms. Acessando o serviço em nuvem de um único banco de dados MySQL.
